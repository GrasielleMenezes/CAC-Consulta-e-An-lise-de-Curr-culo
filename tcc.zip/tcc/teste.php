

<?php

	




	$Array = array(ingles, lft, mad, oc1, prc);
	
	for($i=0; i<=$Array; $i++)
	{	
		if($Array[$i] == $Array[$i+1])
		{
			return 'checked = "true"';
		}


	}



	
	
?>
